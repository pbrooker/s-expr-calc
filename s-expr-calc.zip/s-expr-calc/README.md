# s-expr-calc
Basic s-expression calculator in c# that can perform nested addition and multiplation functions


Enter expression in the following format:

          (add 20 (multiply (add 1000 25) 50))
          
